# -*- coding:utf-8 -*-
import pymysql
pymysql.install_as_MySQLdb()
from flask import Flask
from .config import Config
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    from app.urls import urls
    from app.api import api
    app.register_blueprint(urls)
    app.register_blueprint(api)
    app.secret_key = 'sdfdsfdsfsfdsfsf'
    return app