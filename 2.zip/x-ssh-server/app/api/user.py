from . import api
from flask import request, redirect, url_for, session
from ..config import USERNAME, PASSWORD
from functools import wraps





def login_required(func):
    @wraps(func)
    def inner(*args,**kwargs):
        user=session.get('login') 
        if not user:
            return 'not login'
        return func(*args,**kwargs)
    return inner

@api.route('/login', methods=['GET', 'POST'])
def login():
    username = request.args.get('username')
    password = request.args.get('password')
    if username == USERNAME and password == PASSWORD:
        session['login'] = True
        return 'success'
    
    else:
        return 'fail'


@api.route('/logout', methods=['GET'])
@login_required
def logout():
    session['login'] = False
    return 'logout'

@api.route('/test', methods=['GET', 'POST'])
@login_required
def test():
    return 'test'