# -*- coding:utf-8 -*-
from flask import Blueprint

urls = Blueprint('urls', __name__)



@urls.route('/', methods=['GET', 'POST'])
def index():
    return 'helloworld'