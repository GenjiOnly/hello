# -*- coding:utf-8 -*-

from flask import Flask
from .config import Config
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    from app.urls import urls
    app.register_blueprint(urls)

    return app