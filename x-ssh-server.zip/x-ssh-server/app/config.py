# -*- coding:utf-8 -*-

class Config(object):
    HOSTNAME = '139.224.129.134'
    PORT = '3306'
    DATABASE = 'sys' 
    USERNAME = 'itoffice'
    PASSWORD = 'Root2019!!!'
    DB_URI = 'mysql+mysqldb://{}:{}@{}:{}/{}'.format(USERNAME,PASSWORD,HOSTNAME,PORT,DATABASE)
    SQLALCHEMY_DATABASE_URI = DB_URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False