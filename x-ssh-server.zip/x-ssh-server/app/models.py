# -*- coding:utf-8 -*-
from sqlalchemy import Column, Integer, String, DateTime
from app import db


class Host(db.Model):
    __tablename__ = 'hosts'
    id = Column(Integer, primary_key=True)
    ip = Column(String(32))
    user = Column(String(16))
    port = Column(Integer)
    keyfile = Column(String(32))

